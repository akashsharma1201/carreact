import React, { useEffect, useState } from 'react'
import CarCard from '../components/CarCard'
import PaginationCar from '../components/PaginationCar'
import { useDispatch, useSelector } from "react-redux"
import { getCarAction } from '../redux/feature/carSlice'

const HomePage = ({ search }) => {
    const [currentpage, setCurrentPage] = useState(1)
    const [recordsPerPage] = useState(6);
    const dispatch = useDispatch()
    const cars = useSelector((state) => state.cars.data)

    const getData = async () => {
        dispatch(getCarAction())
    }


    useEffect(() => {
        getData()
    }, [currentpage])

    const lastindex = currentpage * recordsPerPage;
    const firstindex = lastindex - recordsPerPage

    // console.log(cars?.filter(el => el.title.toUpperCase() == search.toUpperCase()))

    const bySearch = (cars, search) => {
        if (search) {
            const res = cars?.filter(el => el.title.toUpperCase().includes(search.toUpperCase()))
            return res
        }
        return cars
    }


    console.log(bySearch() , "35")
    return (
        <div className='container my-5'>
            <div className="row">
                {/* {
                    cars?.slice(firstindex, lastindex)?.map((item, index) => {
                        return (
                            <CarCard key={index} car={item} />
                        )
                    })
                } */}



                {
                    bySearch(cars , search)?.slice(firstindex, lastindex)?.map((item, index) => {
                        return (
                            <CarCard key={index} car={item} />
                        )
                    })
                }
                <PaginationCar setCurrentPage={setCurrentPage} />
            </div>
        </div>
    )
}

export default HomePage