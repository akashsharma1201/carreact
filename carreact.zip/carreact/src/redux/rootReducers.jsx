import { combineReducers } from 'redux'
import carReducer from "./feature/carSlice"

export const reducerRoot = combineReducers({
    // here we will be adding reducers
    cars : carReducer
})