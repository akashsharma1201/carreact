import { createSlice ,createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";






export const getCarAction = createAsyncThunk("car/get", async (thunkAPI) => {
    try {
        const result = await axios("../../../data.json")
        return result.data
    } catch (error) {
        console.log(thunkAPI)
    }
})

const initialState = {
    data: [],
    loading: false

}

const carSlice = createSlice({
    name: "carSlice",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(getCarAction.pending, (state) => {
                state.loading = true
            })
            .addCase(getCarAction.fulfilled, (state, action) => {
                state.loading = false
                state.data=(action.payload)
            })
            .addCase(getCarAction.rejected, (state, action) => {
                state.loading = false
                state.error = "Something  Wrong"
            })
    }
})


export default carSlice.reducer