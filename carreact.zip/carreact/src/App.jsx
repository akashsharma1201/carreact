import { useState } from 'react'
import './App.css'
import Header from './components/Header'
import HomePage from './page/HomePage'
import { Routes, Route, Navigate } from "react-router-dom"

function App() {
  const [firstpgame, setFirstPage] = useState(1)
  const [search, setSearch] = useState("")

  return (
    <>
      <Header setSearch={ setSearch} search = {search}  />
      {/* <HomePage /> */}
      <Routes>
        <Route path="/" element={<Navigate to={`/page/${firstpgame}`} />} />
        <Route path="/page/:pagenumber" element={<HomePage  search = {search} />} />
      </Routes>
    </>
  )
}

export default App
