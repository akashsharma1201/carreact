import React from 'react'
import { Pagination } from "@mui/material"
import { useLocation, useNavigate } from 'react-router-dom'

const PaginationCar = ({ setCurrentPage }) => {
    const navigate = useNavigate()
    
    const pg = {
        position: "absolute",
        right: "0",
        top: 10,
        bottom: 20
    }


    const changeCurrentPage = (event, newpage) => {
        setCurrentPage(newpage)
        navigate(`/page/${newpage}`)
    }
    return (
        <>
            <div className="col-12 my-4" style={{ position: "relative" }}>
                <Pagination count={10} shape="rounded" sx={pg} onChange={changeCurrentPage} />
            </div>
        </>
    )
}

export default PaginationCar