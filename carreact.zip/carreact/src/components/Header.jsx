import React, { useState } from 'react'
import "./Header.css"
import { RiArrowDropDownLine } from "react-icons/Ri"
import { BiSearch } from "react-icons/bi"
import { Button, MenuItem, Menu, Fade } from '@mui/material';


const Header = ({search , setSearch}) => {

    // const [search, setSearch] = useState("")
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    console.log(search)

    return (
        <div className='Header'>
            <div className='search-field'>
                <input type='text' value={search} onInput={(event) => setSearch(event.target.value)} placeholder='Search...' />
                <BiSearch />
            </div>
            <div>
                <Button
                    id="fade-button"
                    aria-controls={open ? 'fade-menu' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? 'true' : undefined}
                    onClick={handleClick}
                >
                    Relevence <RiArrowDropDownLine />
                </Button>
                <Menu
                    id="fade-menu"
                    MenuListProps={{
                        'aria-labelledby': 'fade-button',
                    }}
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    TransitionComponent={Fade}
                >
                    <MenuItem onClick={handleClose}>Option A</MenuItem>
                    <MenuItem onClick={handleClose}>Option B</MenuItem>
                    <MenuItem onClick={handleClose}>Option C</MenuItem>
                </Menu>
            </div>
        </div>
    )
}

export default Header