import React from 'react'
import { LuFuel } from "react-icons/lu"
import { FaCar } from "react-icons/fa"
import { TbUsers } from "react-icons/tb"
import { BsSpeedometer } from "react-icons/bs"
import { HiOutlineHeart } from "react-icons/hi"

const CarCard = ({ car }) => {
    return (
        <div className='col-md-4 car-card-wrapper mt-3'>
            <div className="car-card">
                <div className='car-image-wrapper'>
                    <img src={car?.url} className='img-fluid' alt="" />
                </div>
                <div className='car-text-body'>
                    <div className='car-title-and-year'>
                        <h5>{car?.title}</h5>
                        <h6>{car?.year}</h6>
                    </div>
                    <div className='car-feature'>
                        <div className="row">
                            <div className="col-6">
                                < TbUsers />
                                <span>{car?.people} People</span>
                            </div>
                            <div className="col-6">
                                < LuFuel />
                                <span> {car?.fuel}</span>
                            </div>
                            <div className="col-6">
                                < BsSpeedometer />
                                <span>{car?.milege}</span>
                            </div>
                            <div className="col-6">
                                < FaCar />
                                <span> {car?.mode}</span>
                            </div>
                        </div>
                    </div>
                    <div className='card-bottom'>
                        <h4>
                            ${ car?.price} <span>/ month</span>
                        </h4>
                        <div className="card-buttons">
                            <button className='wishlist'><HiOutlineHeart /></button>
                            <button className='rent-now'>Rent now</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default CarCard









//     <div div className = "car-card" >
// <div className='car-image-wrapper'>
//     <img src="https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60" className='img-fluid' alt="" />
// </div>
// <div className='car-text-body'>
//     <div className='car-title-and-year'>
//         <h5>Toyota RAV4</h5>
//         <h6>2021</h6>
//     </div>
//     <div className='car-feature'>
//         <div className="row">
//             <div className="col-6">
//                 < TbUsers />
//                 <span>4 People</span>
//             </div>
//             <div className="col-6">
//                 < LuFuel />
//                 <span> Hybrid</span>
//             </div>
//             <div className="col-6">
//                 < BsSpeedometer />
//                 <span>6.1km / 1-Litre</span>
//             </div>
//             <div className="col-6">
//                 < FaCar />
//                 <span> Automatic</span>
//             </div>
//         </div>
//     </div>
//     <div className='card-bottom'>
//         <h4>
//             $400 <span>/ month</span>
//         </h4>
//         <div className="card-buttons">
//             <button className='wishlist'><HiOutlineHeart /></button>
//             <button className='rent-now'>Rent now</button>
//         </div>
//     </div>
// </div>
// </div >
